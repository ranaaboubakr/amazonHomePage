package Pages;

import base.PageBase;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import java.lang.String;

import java.util.ArrayList;
import java.util.List;

public class HomePage extends PageBase {
    private static final long WEB_DRIVER_WAIT_IN_SECONDS = 60;
    By searchBox = By.id("twotabsearchtextbox");
    By searchIcon=By.id("nav-search-submit-button");
    By firstItem=By.xpath("//*[@cel_widget_id='MAIN-SEARCH_RESULTS-1']");
    By productImage=By.xpath("//div[@id='imgTagWrapperId']//img");
    By quantityDropdown=By.id("quantity");
    By addToCart=By.id("add-to-cart-button");
    By buyNowButton=By.id("buy-now-button");
    By addWarrenty=By.id("attachSiAddCoverage");
    By addedToCartImage=By.id("add-to-cart-confirmation-image");
    By addedToCartText=By.xpath("//div[contains(@class,'sw-atc-message-section')]");
    By Location=By.id("nav-global-location-popover-link");
    By displayedCountry=By.id("glow-ingress-line2");
    By cityDropdownList=By.id("GLUXCityList");

    public HomePage(WebDriver driver) {
        super(driver, WEB_DRIVER_WAIT_IN_SECONDS);
    }

    public void searchForText(String searchTerm) {
        setElement(driver,searchBox,searchTerm);
        clickElement(driver,searchIcon);

    }

    public void clickFirstItemInSearchResult()
    {
        clickElement(driver,firstItem);
    }

    public boolean checkProductUIComponent()
    {
        return isElementVisible(productImage)&&isElementVisible(quantityDropdown)&&isElementVisible(addToCart)&&isElementVisible(buyNowButton);
    }


    public List<String> checkSearhResult()
    {
        List<WebElement> searchElement=driver.findElements(By.xpath("//*[@class='a-size-base-plus a-color-base a-text-normal']"));
         List<String>searchResult=new ArrayList<String>();
         for (WebElement item:searchElement)
         {
             searchResult.add( item.getText());


         }
        System.out.println(searchResult.size());
      return searchResult;
    }

    public void addItemToCart()
    {
        clickElement(driver,addToCart);
        clickElement(driver,addWarrenty);
    }
    public boolean checkThatItemAddedToCart()
    {
        return isElementVisible(addedToCartImage)&&isElementVisible(addedToCartText);
    }
}
