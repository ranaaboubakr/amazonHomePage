package base;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;


public class PageBase {


    protected final WebDriver driver;
    protected final WebDriverWait wait;


    public PageBase(WebDriver driver) {
        this(driver, 60);
    }

    public PageBase(WebDriver driver, long waitInSeconds) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, waitInSeconds);

    }

    public boolean isElementVisible(By elementLocator) {
        try {
            wait.until(ExpectedConditions.visibilityOfElementLocated(elementLocator));
            return true;
        } catch (Exception e) {

            return false;
        }
    }

    public boolean isElementInvisible(By elementLocator) {
        try {
            wait.until(ExpectedConditions.invisibilityOfElementLocated(elementLocator));

            return true;
        } catch (Exception e) {

            return false;
        }
    }



    public boolean isElementClickable(By elementLocator) {

            wait.until(ExpectedConditions.elementToBeClickable(elementLocator));
            return true;
    }

    public void selectItemFromList(WebDriver driver, By elementLocator, String value) {

        isElementVisible(elementLocator);

            new Select(driver.findElement(elementLocator)).selectByVisibleText(value);
    }
    public void setElement(WebDriver driver, By elementLocator, String value) {

        isElementVisible(elementLocator);
        try {
            driver.findElement(elementLocator).clear();
            driver.findElement(elementLocator).sendKeys(value);

        } catch (Exception e) {

        }

    }
    public void clickElement(WebDriver driver, By elementLocator) {

        if (isElementClickable(elementLocator)) {
            WebElement element = driver.findElement(elementLocator);
            element.click();

        } else {

        }
    }



}
