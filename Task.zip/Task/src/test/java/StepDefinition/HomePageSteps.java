package StepDefinition;

import Pages.HomePage;
import base.TestBase;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

import static org.junit.Assert.*;

import org.testng.Assert;

import java.util.Locale;
import java.util.Objects;

public class HomePageSteps extends TestBase {
    HomePage homepage;

    private void checkAndInitializePageObjects() {
        if (Objects.isNull(homepage)) {
            homepage = new HomePage(driver);
        }
    }

    @Given("^User navigate to WebSite$")
    public void user_navigate_to_website() {
        openBrowser();
    }

    @When("^Type (.+) in search Box$")
    public void type_in_search_box(String searchTerm) {
        checkAndInitializePageObjects();
        homepage.searchForText(searchTerm);
    }

    @Then("^check that result contain (.+)$")
    public void check_that_result_contain(String searchTerm) {
        for (String searchItem : homepage.checkSearhResult()) {
            System.out.println(searchTerm.toLowerCase().substring(0,6));
            assertTrue(searchItem.toLowerCase().contains(searchTerm.toLowerCase().substring(0,6)));
        }
    }

    @Then("^choose first item in result$")
    public void choose_first_item_in_result() {
        checkAndInitializePageObjects();
        homepage.clickFirstItemInSearchResult();
    }

    @Then("^Check product UI Component$")
    public void check_product_ui_component() {
        checkAndInitializePageObjects();
        Assert.assertTrue(homepage.checkProductUIComponent());
    }

    @When("^Click Add to Cart Button$")
    public void click_add_to_cart_button(){
        checkAndInitializePageObjects();
    homepage.addItemToCart();
    }

    @Then("^Item Added to Cart$")
    public void item_added_to_cart()  {
        checkAndInitializePageObjects();
Assert.assertTrue(homepage.checkThatItemAddedToCart());
    }
    @Then("^user close the browser$")
    public void user_close_the_browser()  {
      closeBrowser();
    }
}
